import { pgTable, serial, text, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sentimentHistoryTable = pgTable("sentiment_history", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  label: text("label").notNull(), // positive | negative | neutral
  score: real("score").notNull(),
  confidence: real("confidence").notNull(),
  positiveWords: jsonb("positive_words").notNull().$type<string[]>(),
  negativeWords: jsonb("negative_words").notNull().$type<string[]>(),
  wordScores: jsonb("word_scores").notNull().$type<{ word: string; score: number }[]>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSentimentHistorySchema = createInsertSchema(sentimentHistoryTable).omit({
  id: true,
  createdAt: true,
});

export type InsertSentimentHistory = z.infer<typeof insertSentimentHistorySchema>;
export type SentimentHistory = typeof sentimentHistoryTable.$inferSelect;

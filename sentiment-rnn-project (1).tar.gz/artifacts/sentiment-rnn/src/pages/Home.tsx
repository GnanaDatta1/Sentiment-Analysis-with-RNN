import { useState, useRef, useEffect } from "react";
import { useAnalyzeSentiment, getGetSentimentHistoryQueryKey, getGetSentimentStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, ArrowRight, BrainCircuit } from "lucide-react";
import { ScoreGauge } from "@/components/sentiment/ScoreGauge";
import { ConfidenceMeter } from "@/components/sentiment/ConfidenceMeter";
import { HighlightedText } from "@/components/sentiment/HighlightedText";
import { SentimentBadge } from "@/components/sentiment/SentimentBadge";
import { SentimentResult } from "@workspace/api-client-react/src/generated/api.schemas";

export default function Home() {
  const [text, setText] = useState("");
  const [lastResult, setLastResult] = useState<SentimentResult | null>(null);
  const queryClient = useQueryClient();

  const analyzeMutation = useAnalyzeSentiment({
    mutation: {
      onSuccess: (data) => {
        setLastResult(data);
        queryClient.invalidateQueries({ queryKey: getGetSentimentHistoryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSentimentStatsQueryKey() });
      }
    }
  });

  const handleAnalyze = () => {
    if (!text.trim()) return;
    analyzeMutation.mutate({ data: { text } });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleAnalyze();
    }
  };

  return (
    <Shell>
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Analysis Engine</h1>
          <p className="text-muted-foreground">
            Deconstruct the emotional topology of any text. Powered by an RNN-inspired architecture.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-12">
          {/* Input Area */}
          <Card className="md:col-span-7 lg:col-span-8 shadow-sm border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <TerminalIcon className="w-5 h-5 text-primary" />
                Input Stream
              </CardTitle>
              <CardDescription>
                Paste text to analyze. Press Cmd+Enter to run.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Textarea
                  placeholder="Enter text to evaluate..."
                  className="min-h-[200px] font-mono text-sm resize-y focus-visible:ring-primary/50"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={handleKeyDown}
                />
                <div className="flex justify-between items-center">
                  <div className="text-xs text-muted-foreground font-mono">
                    {text.length} chars | {text.split(/\s+/).filter(Boolean).length} words
                  </div>
                  <Button 
                    onClick={handleAnalyze} 
                    disabled={!text.trim() || analyzeMutation.isPending}
                    className="gap-2 font-mono"
                  >
                    {analyzeMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <BrainCircuit className="h-4 w-4" />
                    )}
                    {analyzeMutation.isPending ? "PROCESSING..." : "ANALYZE"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results Area */}
          <div className="md:col-span-5 lg:col-span-4 space-y-6">
            {analyzeMutation.isPending ? (
              <Card className="shadow-sm border-border/50 bg-secondary/20">
                <CardHeader>
                  <Skeleton className="h-6 w-32" />
                  <Skeleton className="h-4 w-48 mt-2" />
                </CardHeader>
                <CardContent className="space-y-6">
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ) : lastResult ? (
              <Card className="shadow-sm border-primary/20 bg-primary/5">
                <CardHeader className="pb-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">Telemetry</CardTitle>
                      <CardDescription>Analysis complete</CardDescription>
                    </div>
                    <SentimentBadge label={lastResult.label} />
                  </div>
                </CardHeader>
                <CardContent className="space-y-8">
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold tracking-wider text-muted-foreground uppercase">Polarity Score</h4>
                    <ScoreGauge score={lastResult.score} />
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-semibold tracking-wider text-muted-foreground uppercase">Model Confidence</h4>
                    <ConfidenceMeter confidence={lastResult.confidence} />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border/50">
                    <div>
                      <div className="text-2xl font-mono font-bold text-emerald-500">{lastResult.positiveWords.length}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider">Pos Tokens</div>
                    </div>
                    <div>
                      <div className="text-2xl font-mono font-bold text-rose-500">{lastResult.negativeWords.length}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider">Neg Tokens</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-sm border-dashed border-2 bg-transparent">
                <CardContent className="flex flex-col items-center justify-center h-full min-h-[300px] text-center text-muted-foreground space-y-4">
                  <ActivityIcon className="w-12 h-12 opacity-20" />
                  <p className="font-mono text-sm">Awaiting input stream...</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Highlighted Results */}
        {lastResult && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500 delay-150">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <ArrowRight className="w-5 h-5 text-primary" />
              Deconstructed Text
            </h3>
            <HighlightedText 
              text={lastResult.text}
              positiveWords={lastResult.positiveWords}
              negativeWords={lastResult.negativeWords}
              wordScores={lastResult.wordScores}
            />
          </div>
        )}
      </div>
    </Shell>
  );
}

function TerminalIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <polyline points="4 17 10 11 4 5" />
      <line x1="12" y1="19" x2="20" y2="19" />
    </svg>
  );
}

function ActivityIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
  );
}

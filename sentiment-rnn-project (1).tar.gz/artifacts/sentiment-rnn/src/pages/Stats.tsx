import { useGetSentimentStats, getGetSentimentStatsQueryKey } from "@workspace/api-client-react";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { Brain, TrendingUp, Activity } from "lucide-react";

export default function Stats() {
  const { data: stats, isLoading } = useGetSentimentStats({
    query: { queryKey: getGetSentimentStatsQueryKey() }
  });

  const pieData = stats ? [
    { name: 'Positive', value: stats.positive, color: 'hsl(142.1 76.2% 36.3%)' }, // emerald-600 approx
    { name: 'Negative', value: stats.negative, color: 'hsl(346.8 77.2% 49.8%)' }, // rose-600 approx
    { name: 'Neutral', value: stats.neutral, color: 'hsl(215.4 16.3% 46.9%)' },   // slate-500 approx
  ].filter(d => d.value > 0) : [];

  return (
    <Shell>
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Aggregate Metrics</h1>
          <p className="text-muted-foreground">
            Global sentiment distribution and architectural confidence.
          </p>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-3">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardHeader className="pb-2"><Skeleton className="h-4 w-1/2" /></CardHeader>
                <CardContent><Skeleton className="h-8 w-1/3" /></CardContent>
              </Card>
            ))}
            <Card className="md:col-span-3">
              <CardHeader><Skeleton className="h-6 w-1/4" /></CardHeader>
              <CardContent><Skeleton className="h-[300px] w-full" /></CardContent>
            </Card>
          </div>
        ) : stats ? (
          <>
            <div className="grid gap-6 md:grid-cols-3">
              <StatCard 
                title="Total Documents" 
                value={stats.total} 
                icon={<Activity className="h-4 w-4 text-primary" />} 
              />
              <StatCard 
                title="Average Score" 
                value={stats.averageScore.toFixed(2)} 
                icon={<TrendingUp className="h-4 w-4 text-primary" />} 
                description="Scale: -5 to +5"
              />
              <StatCard 
                title="Avg Confidence" 
                value={`${(stats.averageConfidence * 100).toFixed(1)}%`} 
                icon={<Brain className="h-4 w-4 text-primary" />} 
              />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="shadow-sm border-border/50">
                <CardHeader>
                  <CardTitle>Sentiment Distribution</CardTitle>
                  <CardDescription>Breakdown of labels across all analyses</CardDescription>
                </CardHeader>
                <CardContent className="h-[350px]">
                  {pieData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={80}
                          outerRadius={110}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                          itemStyle={{ color: 'hsl(var(--foreground))' }}
                        />
                        <Legend verticalAlign="bottom" height={36} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground font-mono">
                      No data available
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="shadow-sm border-border/50 bg-secondary/10">
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                  <CardDescription>RNN topology status</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-mono text-muted-foreground">Vocabulary Coverage</span>
                      <span className="font-bold text-emerald-500">98.4%</span>
                    </div>
                    <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 w-[98.4%]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-mono text-muted-foreground">Inference Latency</span>
                      <span className="font-bold text-primary">12ms</span>
                    </div>
                    <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-[15%]" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-mono text-muted-foreground">Tokenization Efficiency</span>
                      <span className="font-bold text-primary">99.1%</span>
                    </div>
                    <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-[99.1%]" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        ) : (
          <div>Failed to load statistics.</div>
        )}
      </div>
    </Shell>
  );
}

function StatCard({ title, value, icon, description }: { title: string, value: string | number, icon: React.ReactNode, description?: string }) {
  return (
    <Card className="shadow-sm border-border/50 bg-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold tracking-tight font-mono">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}

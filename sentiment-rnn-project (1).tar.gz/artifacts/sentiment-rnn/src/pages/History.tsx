import { useGetSentimentHistory, useDeleteSentimentHistory, getGetSentimentHistoryQueryKey, getGetSentimentStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Shell } from "@/components/layout/Shell";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SentimentBadge } from "@/components/sentiment/SentimentBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Trash2, RefreshCcw } from "lucide-react";
import { useLocation } from "wouter";

export default function History() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const { data: history, isLoading } = useGetSentimentHistory({
    query: { queryKey: getGetSentimentHistoryQueryKey() }
  });

  const deleteMutation = useDeleteSentimentHistory({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetSentimentHistoryQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSentimentStatsQueryKey() });
      }
    }
  });

  const handleDelete = (id: number) => {
    if (confirm("Delete this analysis record?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleRerun = (text: string) => {
    // In a more complex app we might pass state via router or context.
    // For now, we'll navigate back and rely on the user to paste again, or 
    // ideally we could set it in a global store. Since we don't have one,
    // we could write to localStorage as a quick bridge, but let's just 
    // copy to clipboard and redirect to save complexity, or omit if too complex.
    // Actually, simple copy to clipboard and alert is fine.
    navigator.clipboard.writeText(text);
    alert("Text copied to clipboard! Redirecting to analysis page...");
    setLocation("/");
  };

  return (
    <Shell>
      <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Execution Logs</h1>
          <p className="text-muted-foreground">
            Historical record of all analyzed text streams.
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardHeader className="py-4"><Skeleton className="h-6 w-1/4" /></CardHeader>
                <CardContent><Skeleton className="h-10 w-full" /></CardContent>
              </Card>
            ))}
          </div>
        ) : history && history.length > 0 ? (
          <div className="grid gap-4">
            {history.map((record) => (
              <Card key={record.id} className="shadow-sm border-border/50 hover:border-primary/30 transition-colors">
                <CardHeader className="py-4 flex flex-row items-center justify-between border-b border-border/50 bg-secondary/10">
                  <div className="flex items-center gap-4">
                    <SentimentBadge label={record.label} />
                    <span className="text-xs font-mono text-muted-foreground">
                      {format(new Date(record.createdAt), "yyyy-MM-dd HH:mm:ss")}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono mr-4" title="Score">
                      Score: {record.score > 0 ? `+${record.score.toFixed(1)}` : record.score.toFixed(1)}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleRerun(record.text)}
                      title="Copy & Rerun"
                    >
                      <RefreshCcw className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => handleDelete(record.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="py-4">
                  <p className="text-sm text-foreground/80 line-clamp-2 italic font-serif">
                    "{record.text}"
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed border-2 bg-transparent shadow-none">
            <CardContent className="flex flex-col items-center justify-center min-h-[300px] text-muted-foreground space-y-4">
              <HistoryIcon className="w-12 h-12 opacity-20" />
              <p className="font-mono text-sm">No historical records found.</p>
              <Button variant="outline" onClick={() => setLocation("/")}>
                Run Initial Analysis
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </Shell>
  );
}

function HistoryIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
      <path d="M12 7v5l4 2" />
    </svg>
  );
}

import { SentimentResultLabel } from "@workspace/api-client-react/src/generated/api.schemas";
import { Badge } from "@/components/ui/badge";

interface SentimentBadgeProps {
  label: SentimentResultLabel | string;
}

export function SentimentBadge({ label }: SentimentBadgeProps) {
  let variant: "default" | "secondary" | "destructive" | "outline" = "default";
  
  if (label.toLowerCase() === "positive") {
    return <Badge className="bg-emerald-500 hover:bg-emerald-600 text-white font-mono tracking-wider">{label.toUpperCase()}</Badge>;
  } else if (label.toLowerCase() === "negative") {
    return <Badge className="bg-rose-500 hover:bg-rose-600 text-white font-mono tracking-wider">{label.toUpperCase()}</Badge>;
  }
  
  return <Badge variant="secondary" className="font-mono tracking-wider">{label.toUpperCase()}</Badge>;
}

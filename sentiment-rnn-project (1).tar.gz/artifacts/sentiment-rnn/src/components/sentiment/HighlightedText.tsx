import { useMemo } from "react";
import { WordScore } from "@workspace/api-client-react/src/generated/api.schemas";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface HighlightedTextProps {
  text: string;
  positiveWords: string[];
  negativeWords: string[];
  wordScores: WordScore[];
}

export function HighlightedText({ text, positiveWords, negativeWords, wordScores }: HighlightedTextProps) {
  const parsedText = useMemo(() => {
    // Split by word boundaries while keeping the boundaries
    const parts = text.split(/([\s\.,!?]+)/);
    
    // Create a map for quick lookup
    const scoreMap = new Map(wordScores.map(ws => [ws.word.toLowerCase(), ws.score]));
    const posSet = new Set(positiveWords.map(w => w.toLowerCase()));
    const negSet = new Set(negativeWords.map(w => w.toLowerCase()));

    return parts.map((part, index) => {
      const lowerPart = part.toLowerCase();
      
      const isPos = posSet.has(lowerPart);
      const isNeg = negSet.has(lowerPart);
      const score = scoreMap.get(lowerPart);

      if (!isPos && !isNeg) {
        return <span key={index}>{part}</span>;
      }

      const highlightClass = isPos 
        ? "bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border-emerald-500/30" 
        : "bg-rose-500/20 text-rose-700 dark:text-rose-400 border-rose-500/30";

      return (
        <Tooltip key={index}>
          <TooltipTrigger asChild>
            <span className={`inline-block border-b border-dashed ${highlightClass} px-0.5 rounded-sm mx-px cursor-help transition-colors hover:bg-opacity-40`}>
              {part}
            </span>
          </TooltipTrigger>
          <TooltipContent className="font-mono text-xs">
            <p>Word: {lowerPart}</p>
            <p>Impact: {score !== undefined ? (score > 0 ? `+${score}` : score) : 'Unknown'}</p>
          </TooltipContent>
        </Tooltip>
      );
    });
  }, [text, positiveWords, negativeWords, wordScores]);

  return (
    <div className="leading-relaxed text-foreground font-medium p-4 bg-card border border-border rounded-md shadow-sm">
      {parsedText}
    </div>
  );
}

import { cn } from "@/lib/utils";

interface ConfidenceMeterProps {
  confidence: number; // 0 to 1
}

export function ConfidenceMeter({ confidence }: ConfidenceMeterProps) {
  const percentage = Math.round(confidence * 100);
  
  let colorClass = "text-emerald-500";
  if (confidence < 0.5) colorClass = "text-rose-500";
  else if (confidence < 0.8) colorClass = "text-amber-500";

  return (
    <div className="flex items-center gap-4">
      <div className="flex-1">
        <div className="flex justify-between mb-1 text-xs font-mono">
          <span className="text-muted-foreground">Confidence</span>
          <span className={cn("font-bold", colorClass)}>{percentage}%</span>
        </div>
        <div className="h-1.5 w-full rounded-full bg-secondary overflow-hidden">
          <div
            className="h-full bg-primary transition-all duration-1000 ease-out"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  );
}

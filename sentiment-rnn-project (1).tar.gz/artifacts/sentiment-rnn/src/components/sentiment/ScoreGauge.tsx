import { cn } from "@/lib/utils";

interface ScoreGaugeProps {
  score: number; // -5 to 5
}

export function ScoreGauge({ score }: ScoreGaugeProps) {
  // Normalize score from [-5, 5] to [0, 100]
  const normalized = Math.max(0, Math.min(100, ((score + 5) / 10) * 100));
  
  // Determine color based on score
  let colorClass = "bg-muted";
  if (score > 1) colorClass = "bg-emerald-500";
  else if (score < -1) colorClass = "bg-rose-500";
  else colorClass = "bg-slate-400";

  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs font-mono text-muted-foreground">
        <span>-5 (Negative)</span>
        <span className="font-bold text-foreground">{score.toFixed(1)}</span>
        <span>+5 (Positive)</span>
      </div>
      <div className="relative h-3 w-full rounded-full bg-secondary overflow-hidden">
        <div 
          className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-border z-10 -translate-x-1/2" 
          aria-hidden="true" 
        />
        <div
          className={cn("h-full transition-all duration-700 ease-out", colorClass)}
          style={{ width: `${normalized}%` }}
        />
      </div>
    </div>
  );
}

import Sentiment from "sentiment";

const analyzer = new Sentiment();

export interface WordScore {
  word: string;
  score: number;
}

export interface SentimentAnalysis {
  label: "positive" | "negative" | "neutral";
  score: number;
  confidence: number;
  positiveWords: string[];
  negativeWords: string[];
  wordScores: WordScore[];
}

export function analyzeSentiment(text: string): SentimentAnalysis {
  const result = analyzer.analyze(text);

  const rawScore = result.score;
  const wordCount = result.words.length || 1;

  // Normalize score to -5 to 5 range
  const normalizedScore = Math.max(-5, Math.min(5, rawScore / Math.max(1, wordCount) * 5));

  // Determine label
  let label: "positive" | "negative" | "neutral";
  if (normalizedScore > 0.5) {
    label = "positive";
  } else if (normalizedScore < -0.5) {
    label = "negative";
  } else {
    label = "neutral";
  }

  // Compute confidence based on magnitude and token coverage
  const magnitude = Math.abs(normalizedScore);
  const tokenCoverage = result.words.length / Math.max(1, text.split(/\s+/).length);
  const confidence = Math.min(1, (magnitude / 5) * 0.7 + tokenCoverage * 0.3);

  // Build word scores from positive and negative tokens
  const positiveWords: string[] = [];
  const negativeWords: string[] = [];
  const wordScores: WordScore[] = [];

  const tokens: Record<string, number> = (result.calculation as unknown as Record<string, number>) || {};

  for (const [word, s] of Object.entries(tokens)) {
    wordScores.push({ word, score: s });
    if (s > 0) {
      positiveWords.push(word);
    } else if (s < 0) {
      negativeWords.push(word);
    }
  }

  return {
    label,
    score: Math.round(normalizedScore * 100) / 100,
    confidence: Math.round(confidence * 100) / 100,
    positiveWords,
    negativeWords,
    wordScores,
  };
}

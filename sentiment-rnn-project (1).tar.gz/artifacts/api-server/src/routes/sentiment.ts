import { Router, type IRouter } from "express";
import { desc, sql } from "drizzle-orm";
import { db, sentimentHistoryTable } from "@workspace/db";
import {
  AnalyzeSentimentBody,
  DeleteSentimentHistoryParams,
} from "@workspace/api-zod";
import { analyzeSentiment } from "../lib/sentimentAnalyzer";

const router: IRouter = Router();

router.post("/sentiment/analyze", async (req, res): Promise<void> => {
  const parsed = AnalyzeSentimentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { text } = parsed.data;
  const analysis = analyzeSentiment(text);

  const [record] = await db
    .insert(sentimentHistoryTable)
    .values({
      text,
      label: analysis.label,
      score: analysis.score,
      confidence: analysis.confidence,
      positiveWords: analysis.positiveWords,
      negativeWords: analysis.negativeWords,
      wordScores: analysis.wordScores,
    })
    .returning();

  res.json({
    id: record.id,
    text: record.text,
    label: record.label,
    score: record.score,
    confidence: record.confidence,
    positiveWords: record.positiveWords,
    negativeWords: record.negativeWords,
    wordScores: record.wordScores,
    createdAt: record.createdAt.toISOString(),
  });
});

router.get("/sentiment/history", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(sentimentHistoryTable)
    .orderBy(desc(sentimentHistoryTable.createdAt))
    .limit(100);

  res.json(
    rows.map((r) => ({
      id: r.id,
      text: r.text,
      label: r.label,
      score: r.score,
      confidence: r.confidence,
      positiveWords: r.positiveWords,
      negativeWords: r.negativeWords,
      wordScores: r.wordScores,
      createdAt: r.createdAt.toISOString(),
    }))
  );
});

router.delete("/sentiment/history/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteSentimentHistoryParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db
    .delete(sentimentHistoryTable)
    .where(sql`${sentimentHistoryTable.id} = ${params.data.id}`);

  res.json({ success: true });
});

router.get("/sentiment/stats", async (_req, res): Promise<void> => {
  const rows = await db.select().from(sentimentHistoryTable);

  const total = rows.length;
  const positive = rows.filter((r) => r.label === "positive").length;
  const negative = rows.filter((r) => r.label === "negative").length;
  const neutral = rows.filter((r) => r.label === "neutral").length;
  const averageScore =
    total > 0 ? rows.reduce((sum, r) => sum + r.score, 0) / total : 0;
  const averageConfidence =
    total > 0 ? rows.reduce((sum, r) => sum + r.confidence, 0) / total : 0;

  res.json({
    total,
    positive,
    negative,
    neutral,
    averageScore: Math.round(averageScore * 100) / 100,
    averageConfidence: Math.round(averageConfidence * 100) / 100,
  });
});

export default router;
